import React from 'react';
import { Globe, Info, Map } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-blue-900 text-white py-8 mt-8">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <Globe className="w-6 h-6 mr-2" />
            <span className="font-semibold text-lg">Atlas App</span>
          </div>
          
          <div className="flex space-x-6">
            <a 
              href="#" 
              className="text-blue-200 hover:text-white transition-colors flex items-center"
            >
              <Info className="w-4 h-4 mr-1" />
              <span>About</span>
            </a>
            <a 
              href="#" 
              className="text-blue-200 hover:text-white transition-colors flex items-center"
            >
              <Map className="w-4 h-4 mr-1" />
              <span>Explore</span>
            </a>
          </div>
        </div>
        
        <div className="mt-6 pt-6 border-t border-blue-800 text-center text-blue-300 text-sm">
          <p>&copy; {new Date().getFullYear()} Atlas App. All geography data is provided for educational purposes.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;