import React from 'react';
import { Globe } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-6 mb-8">
      <div className="container mx-auto px-4 flex items-center justify-center">
        <div className="text-center">
          <div className="flex items-center justify-center mb-3">
            <Globe className="w-8 h-8 mr-2" />
            <h1 className="text-3xl font-bold tracking-tight">Atlas App</h1>
          </div>
          <p className="text-blue-100 max-w-md mx-auto">
            Explore cities, states, and countries from around the world
          </p>
        </div>
      </div>
    </header>
  );
};

export default Header;