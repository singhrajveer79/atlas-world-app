import React from 'react';

interface AlphabetSelectorProps {
  onSelectLetter: (letter: string) => void;
  selectedLetter: string | null;
}

const AlphabetSelector: React.FC<AlphabetSelectorProps> = ({ onSelectLetter, selectedLetter }) => {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

  return (
    <div className="flex flex-wrap justify-center gap-2 md:gap-3 mb-8">
      {alphabet.map((letter) => (
        <button
          key={letter}
          onClick={() => onSelectLetter(letter)}
          className={`
            w-10 h-10 md:w-12 md:h-12 
            flex items-center justify-center 
            rounded-lg md:rounded-xl 
            font-medium text-lg md:text-xl 
            transition-all duration-300 
            shadow-sm hover:shadow-md
            ${
              selectedLetter === letter
                ? 'bg-blue-800 text-white scale-110'
                : 'bg-white text-blue-800 hover:bg-blue-50'
            }
          `}
          aria-pressed={selectedLetter === letter}
        >
          {letter}
        </button>
      ))}
    </div>
  );
};

export default AlphabetSelector;