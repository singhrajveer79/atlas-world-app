import React, { useState, useEffect } from 'react';
import { Mic, MicOff } from 'lucide-react';

interface VoiceAssistantProps {
  onRecognized: (letter: string) => void;
}

const VoiceAssistant: React.FC<VoiceAssistantProps> = ({ onRecognized }) => {
  const [isListening, setIsListening] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [supported, setSupported] = useState(true);

  useEffect(() => {
    // Check if browser supports SpeechRecognition
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      setSupported(false);
      setStatusMessage('Voice recognition not supported in this browser');
    }
  }, []);

  const toggleListening = () => {
    if (!supported) return;
    
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const startListening = () => {
    setIsListening(true);
    setStatusMessage('Listening...');
    
    // Use the appropriate SpeechRecognition constructor
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    
    recognition.onresult = (event: any) => {
      const speechResult = event.results[0][0].transcript.trim().toUpperCase();
      setStatusMessage(`Recognized: "${speechResult}"`);
      
      // Check if it's a single letter
      if (speechResult.length === 1 && /[A-Z]/.test(speechResult)) {
        onRecognized(speechResult);
      } else if (speechResult.startsWith("LETTER ") && speechResult.length > 7) {
        const letter = speechResult.charAt(7).toUpperCase();
        if (/[A-Z]/.test(letter)) {
          onRecognized(letter);
        }
      }
      
      setIsListening(false);
    };
    
    recognition.onerror = (event: any) => {
      setStatusMessage(`Error: ${event.error}`);
      setIsListening(false);
    };
    
    recognition.onend = () => {
      setIsListening(false);
      setStatusMessage('');
    };
    
    recognition.start();
  };
  
  const stopListening = () => {
    setIsListening(false);
    setStatusMessage('');
  };

  if (!supported) {
    return (
      <div className="flex items-center justify-center mb-4 opacity-50">
        <MicOff className="w-5 h-5 mr-2 text-gray-500" />
        <p className="text-sm text-gray-500">Voice recognition not supported</p>
      </div>
    );
  }

  return (
    <div className="mb-6">
      <button
        onClick={toggleListening}
        className={`
          flex items-center justify-center gap-2 
          rounded-full px-4 py-2 
          transition-all duration-300
          ${isListening 
            ? 'bg-red-500 text-white animate-pulse' 
            : 'bg-blue-50 text-blue-800 hover:bg-blue-100'}
        `}
        aria-label={isListening ? 'Stop listening' : 'Start voice input'}
      >
        {isListening ? (
          <>
            <MicOff className="w-5 h-5" />
            <span>Stop Listening</span>
          </>
        ) : (
          <>
            <Mic className="w-5 h-5" />
            <span>Speak a Letter</span>
          </>
        )}
      </button>
      
      {statusMessage && (
        <p className="text-sm text-gray-600 mt-2 text-center">{statusMessage}</p>
      )}
    </div>
  );
};

// Add type definitions for Window interface
declare global {
  interface Window {
    SpeechRecognition?: any;
    webkitSpeechRecognition?: any;
  }
}

export default VoiceAssistant;