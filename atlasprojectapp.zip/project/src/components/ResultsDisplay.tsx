import React from 'react';
import { Location, LocationResults } from '../types';
import { MapPin, Building, Flag } from 'lucide-react';

interface ResultsDisplayProps {
  results: LocationResults;
  selectedLetter: string | null;
  searchQuery: string;
}

const LocationCard: React.FC<{ location: Location; icon: React.ReactNode }> = ({ location, icon }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm p-4 hover:shadow-md transition-shadow duration-300">
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 mt-1 text-blue-700">
          {icon}
        </div>
        <div>
          <h3 className="font-medium text-gray-900">{location.name}</h3>
          {location.description && (
            <p className="text-sm text-gray-600 mt-1">{location.description}</p>
          )}
        </div>
      </div>
    </div>
  );
};

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ results, selectedLetter, searchQuery }) => {
  const { cities, states, countries } = results;
  const totalResults = cities.length + states.length + countries.length;

  if (totalResults === 0) {
    return (
      <div className="text-center py-10 px-4">
        <p className="text-lg text-gray-600">
          {selectedLetter 
            ? `No locations found starting with '${selectedLetter}'` 
            : searchQuery 
              ? `No results found for "${searchQuery}"`
              : 'Select a letter or search to see locations'}
        </p>
      </div>
    );
  }

  const renderSection = (title: string, items: Location[], icon: React.ReactNode) => {
    if (items.length === 0) return null;
    
    return (
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4 text-gray-800 border-b pb-2">{title} ({items.length})</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map(item => (
            <LocationCard key={item.id} location={item} icon={icon} />
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="w-full max-w-6xl mx-auto">
      <p className="text-sm text-gray-500 mb-6">
        {selectedLetter 
          ? `Showing locations starting with '${selectedLetter}'` 
          : `Search results for "${searchQuery}"`}
        {` — ${totalResults} ${totalResults === 1 ? 'result' : 'results'}`}
      </p>
      
      {renderSection('Countries', countries, <Flag className="w-5 h-5" />)}
      {renderSection('States & Provinces', states, <Building className="w-5 h-5" />)}
      {renderSection('Cities', cities, <MapPin className="w-5 h-5" />)}
    </div>
  );
};

export default ResultsDisplay;