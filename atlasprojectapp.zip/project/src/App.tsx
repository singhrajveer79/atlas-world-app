import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import AlphabetSelector from './components/AlphabetSelector';
import SearchBar from './components/SearchBar';
import ResultsDisplay from './components/ResultsDisplay';
import VoiceAssistant from './components/VoiceAssistant';
import { getLocationsByLetter, searchLocations } from './data/locationData';
import { LocationResults } from './types';

function App() {
  const [selectedLetter, setSelectedLetter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<LocationResults>({ cities: [], states: [], countries: [] });

  // Handle letter selection
  const handleLetterSelect = (letter: string) => {
    setSearchQuery('');
    setSelectedLetter(letter);
    const letterResults = getLocationsByLetter(letter);
    setResults(letterResults);
  };

  // Handle search
  const handleSearch = (query: string) => {
    if (query.trim()) {
      setSelectedLetter(null);
      setSearchQuery(query);
      const searchResults = searchLocations(query);
      setResults(searchResults);
    } else {
      setSearchQuery('');
      setResults({ cities: [], states: [], countries: [] });
    }
  };

  // Handle voice recognition
  const handleVoiceRecognition = (letter: string) => {
    handleLetterSelect(letter);
  };

  // Update document title when letter changes
  useEffect(() => {
    document.title = selectedLetter 
      ? `Atlas App - Locations: ${selectedLetter}` 
      : searchQuery 
        ? `Atlas App - Search: ${searchQuery}` 
        : 'Atlas App - Explore the World';
  }, [selectedLetter, searchQuery]);

  return (
    <div className="flex flex-col min-h-screen bg-blue-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 pb-10">
        <div className="flex flex-col items-center justify-center mb-10">
          <h2 className="text-2xl font-semibold text-center text-gray-800 mb-2">
            Explore Locations by Letter
          </h2>
          <p className="text-gray-600 text-center max-w-xl mb-6">
            Click a letter to discover cities, states, and countries from around the world, 
            or use the search to find specific locations.
          </p>
          
          <VoiceAssistant onRecognized={handleVoiceRecognition} />
          
          <SearchBar onSearch={handleSearch} />
          
          <AlphabetSelector 
            onSelectLetter={handleLetterSelect} 
            selectedLetter={selectedLetter} 
          />
        </div>
        
        <div className="w-full">
          <ResultsDisplay 
            results={results} 
            selectedLetter={selectedLetter} 
            searchQuery={searchQuery} 
          />
        </div>
      </main>
      
      <Footer />
    </div>
  );
}

export default App;