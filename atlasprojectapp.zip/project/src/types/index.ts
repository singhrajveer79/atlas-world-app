export interface Location {
  id: string;
  name: string;
  type: 'city' | 'state' | 'country';
  description?: string;
}

export interface LocationResults {
  cities: Location[];
  states: Location[];
  countries: Location[];
}